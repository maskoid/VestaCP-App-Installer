ALTER TABLE "#__contentitem_tag_map" DROP INDEX "#__contentitem_tag_map_idx_tag";
ALTER TABLE "#__contentitem_tag_map" DROP INDEX "#__contentitem_tag_map_idx_type";
